### This is for Question 2

install.packages("ggplot2")
library(igraph)
library(ggplot2)


# create weighted directed network
graph_q2 <- read.graph("Processed/weight_edge_list",format="ncol",directed=TRUE)

# plot in-degree distribution (frequency and probability)
in_degree_distribution_fun(graph_q2)



in_degree_distribution_fun = function(graph) {
    # count the frequency of each degree
    freq <- sort(degree(graph, mode="in"))
    df <- data.frame(degree=c(NA), freq=c(NA))
    df <- df[-1, ]
    curDegree <- freq[1]
    count <- 1
    for (i in 2:length(freq)) {
        if (freq[i] != curDegree) {
            df[nrow(df)+1, ] <- c(curDegree, count)
            curDegree <- freq[i]
            count <- 1
        } else {
            count <- count + 1
        }
    }
    df[nrow(df)+1, ] <- c(curDegree, count)
    
    # plot original degree distribution histogram
    ggplot(df, aes(x=degree, y=freq))+ 
    geom_bar(stat = "identity", fill="blue")+
    labs(title="Actor/Actress Graph - In-Degree Distrubtion And Frequency)", x="In-degree", y="Frequency")+
    theme(plot.title = element_text(hjust = 0.5))
}


