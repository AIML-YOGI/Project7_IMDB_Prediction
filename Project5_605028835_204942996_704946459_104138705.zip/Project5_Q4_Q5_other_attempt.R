# ------------------- Q2 -----------------------#

library(igraph)
library(ggplot2)
library(hash)
library(plyr)
setwd("C:/Users/anupams/OneDrive - Microsoft/Study/Summer 2018/Project 5")

g <- read.graph("Processed/weighted_edges.txt",format="ncol",directed=TRUE)

  frequency <- sort(degree(g, mode="in"))
  curDegree <- frequency[1]
  dataframe <- data.frame(degree=c(NA), frequency=c(NA))
  dataframe <- dataframe[-1, ]
  count <- 1
  length1 <- length(frequency)
  for (i in 2:length1) {
    if (frequency[i] != curDegree) {
      dataframe[nrow(dataframe)+1, ] <- c(curDegree, count)
      curDegree <- frequency[i]
      count <- 1
    } else {
      count <- count + 1
    }
  }
  dataframe[nrow(dataframe)+1, ] <- c(curDegree, count)
  
  ggplot(dataframe, aes(x=degree, y=frequency))+geom_bar(stat = "identity", fill="blue")+labs(title="In-degree Distribution of the Actor/Actress Network", x="In-degree", y="Frequency")

  # ------------------- Q3 -----------------------#
  actors <- c('Tom Cruise', 'Emma Watson (II)', 'George Clooney', 'Tom Hanks', 'Dwayne Johnson (I)', 'Johnny Depp', 'Will Smith (I)', 'Meryl Streep', 'Leonardo DiCaprio', 'Brad Pitt')
  idx <- c('14499', '111286', '12808', '27252', '32383', '16873', '62765', '107820', '17280', '53241')
  length2 <- length(actors)
  weightMax = 0
  idx3 = -1
  for (i in c(1:length2)) {
    idx1 <- idx[i]
    idx2 <- graphIdx[[idx1]]
    neighbors = neighbors(g, as.numeric(idx2), mode = c("out"))
    print(actors[i])
    print(paste('neighbors: ', length(neighbors)))
    
    for (i in neighbors) {
      edgeId = get.edge.ids(g, c(as.numeric(idx2), i), directed = TRUE, error = TRUE, multi = TRUE)
      weightCur = edge_attr(g, "weight", index = edge_id)
      if (weightCur > weightMax) {
        weightMax = weightCur
        idx3 = i
      }
    }
    idx4 = pairOriginal[[as.character(idx3)]]
    print(idxName[[idx4]])
    print(paste('weight: ', weightMax))
}

idxName = hash()
f1 <- file("/Users/Pat/my_232E/my_proj5/processed_data/names", "r")
index = 0
line = readLines(f1, n = 1)
while (length(line) != 0) {
  .set(idxName, index, substr(line, start = 11, stop = nchar(line)))
  line = readLines(f1, n = 1)
  index = index + 1
}

graphIdx = hash()
pairOriginal = hash()
f2 <- file("/Users/Pat/my_232E/my_proj5/processed_data/indices", "r")
line = readLines(f2, n = 1)
while (length(line) != 0) {
  arr = strsplit(line, "[ ]")
  .set(graphIdx, arr[[1]][1], arr[[1]][2])
  .set(pairOriginal, arr[[1]][2], arr[[1]][1])
  line = readLines(f2, n = 1)
}

# ------------------- Q4 -----------------------#

g <- read.graph("Processed/weighted_edges.txt",format="ncol",directed=TRUE)

idxName = hash()
f3 <- file("Processed/index_nameLS.txt", "r")
index = 0
line <- readLines(f3, n = 1)
length3 <- length(line)
while (length3 != 0) {
  .set(idxName, index, substr(line, start = 11, stop = nchar(line)))
  index = index + 1
}

graphIdx = hash()
pairOriginal = hash()
f4 <- file("Processed/indices.txt", "r")
line = readLines(f4, n = 1)
while (length3 != 0) {
  arr = strsplit(line, "[ ]")
  .set(graphIdx, arr[[1]][1], arr[[1]][2])
  .set(pairOriginal, arr[[1]][2], arr[[1]][1])
}


rank = page_rank(g, algo = c("prpack"), vids = V(g), directed = TRUE, damping = 0.85, personalized = NULL, weights = NULL, options = NULL)

length4 <- length(rank$vector)
dataframe <- data.frame(Object=1:length4,PageRank=rank$vector)
top10 <- arrange(dataframe,desc(PageRank))

for (i in c(1:10)) {
  top10Graph = top10[i,1]
  top10Original = pairOriginal[[as.character(top10Graph)]]
  print(idxName[[top10Original]])
  deg1 = degree(g, v = top10Graph, mode = c("in"), loops = TRUE, normalized = FALSE)
  deg2 = degree(g, v = top10Graph, mode = c("out"), loops = TRUE, normalized = FALSE)
  print(paste('in degree:', deg1[[1]]))
}


# ------------------- Q5 -----------------------#
top10Map = hash()
for (i in c(1:length(top10[, 1]))) {
  object = top10[i,1]
  pageRank = top10[i, 2]
  .set(top10Map, object, pageRank)
}

for (i in idx) {
  print(idxName[[i]])
  print(paste('pagerank:', top10Map[[as.character(graphIdx[[as.character(i)]])]]))
  deg3 = degree(g, v = graphIdx[[as.character(i)]], mode = c("in"), loops = TRUE, normalized = FALSE)
  print(paste('in degree:', deg3[[1]]))
}
