
import requests
from IPython.display import HTML
subscription_key = "edf93b2f6ed8451ea4c4ea30e7478808"
#subscription_key = "66935119-b9ca-429d-9cb2-10d7e8e377cf"

### Using Bing Search API to get results of top 10 rank actors
assert subscription_key

search_url = "https://api.cognitive.microsoft.com/bing/v7.0/search"


import numpy as np
search_term = "Tatasciore, Fred"

headers = {"Ocp-Apim-Subscription-Key" : subscription_key}

sig_acts = ['Flowers, Bess', 'Tatasciore, Fred', 'Harris, Sam (II)', 'Blum, Steve (IX)', 'Miller, Harold (I)', 'Jeremy, Ron', 'Lowenthal, Yuri', 'Phelps, Lee (I)', 'Downes, Robin Atkin', 'O\'Connor, Frank (I)']
search_results = []
parameters = []
for i in range(10):
    print('===================')
    print(sig_acts[i])
   
    parameters = {"q": sig_acts[i], "textDecorations":True, "textFormat":"HTML"}
    response = requests.get(search_url, headers=headers, params=parameters)
    response.raise_for_status()
    search_results = np.append(search_results, response.json())
    print(search_results)
    print('===================')



## some additioanl analysis for Q4 and Question 5

node_movies = {}
with open('preprocess_data/trim', 'r') as f1:
    for line in f1:
        name_movies = line.split('\t\t')
        movies = set()
        for index in range(1, len(name_movies), 1):
            movies.add(name_movies[index])
        node_movies[name_movies[0]] = movies
sig_acts = ['Flowers, Bess', 'Tatasciore, Fred', 'Harris, Sam (II)', 'Blum, Steve (IX)', 'Miller, Harold (I)', 'Jeremy, Ron', 'Lowenthal, Yuri', 'Phelps, Lee (I)', 'Downes, Robin Atkin', 'O\'Connor, Frank (I)']

for i in range(10):
    sig_movies = node_movies[sig_acts[i]]
    print('=========' + str(i+1) + '==========')
    print(sig_acts[i] + ': ' + str(len(sig_movies)) + ' movies')
    print('')


# Some additional Analysis for Q5
input_acts = ['Cruise, Tom', 'Watson, Emma (II)', 'Clooney, George', 'Hanks, Tom', 'Johnson, Dwayne (I)', 'Depp, Johnny', 'Smith, Will (I)', 'Streep, Meryl', 'DiCaprio, Leonardo', 'Pitt, Brad']

for i in range(10):
    input_movies = node_movies[input_acts[i]]
    print('=========' + str(i+1) + '==========')
    print(input_acts[i] + ': ' + str(len(input_movies)) + ' movies')
    print('')

