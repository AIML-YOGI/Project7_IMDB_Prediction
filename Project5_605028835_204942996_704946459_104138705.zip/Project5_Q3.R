library(igraph)
library(hash)
library(ggplot2)

graph <- read.graph("/Users/Patrick/my 232E/my proj5/processed_data/weighted_edges",format="ncol",directed=TRUE)
actors <- c('Tom Cruise', 'Emma Watson (II)', 'George Clooney', 'Tom Hanks', 'Dwayne Johnson (I)', 'Johnny Depp', 'Will Smith (I)', 'Meryl Streep', 'Leonardo DiCaprio', 'Brad Pitt')
idx <- c('14499', '111286', '12808', '27252', '32383', '16873', '62765', '107820', '17280', '53241')
length2 <- length(actors)
weightMax = 0
for (i in c(1:length2)) {
  idx1 <- idx[i]
  idx2 <- graphIdx[[idx1]]
  neighbors = neighbors(graph, as.numeric(idx2), mode = c("out"))
  print(actors[i])
  print(paste('neighbors: ', length(neighbors)))
  idx3 = -1
  for (i in neighbors) {
    edgeId = get.edge.ids(graph, c(as.numeric(idx2), i), directed = TRUE, error = TRUE, multi = TRUE)
    weightCur = edge_attr(g, "weight", index = edge_id)
    if (weightCur > weightMax) {
      weightMax = weightCur
      idx3 = i
    }
  }
  idx4 = pairOriginal[[as.character(idx3)]]
  print(idxName[[idx4]])
  print(paste('weight: ', weightMax))
}

idxName = hash()
file1 <- file("/Users/Patrick/my 232E/my proj5/processed_data/names", "r")
index = 0
line1 = readLines(file1, n = 1)
while (length(line1) != 0) {
  set(idxName, index, substr(line1, start = 11, stop = nchar(line1)))
  line1 = readLines(file1, n = 1)
  index = index + 1
}

graphIdx = hash()
pairOriginal = hash()
file2 <- file("/Users/Patrick/my 232E/my proj5/processed_data/indices", "r")
line2 = readLines(file2, n = 1)
while (length(line2) != 0) {
  arr = strsplit(line2, "[ ]")
  set(graphIdx, arr[[1]][1], arr[[1]][2])
  set(pairOriginal, arr[[1]][2], arr[[1]][1])
  line2 = readLines(file2, n = 1)
}
