#
# This part of the code covers Question 4 and Question 5 for Project 5
#
#
install.packages("hash")
library(hash)
library(plyr)
library(igraph)
library(ggplot2)

## Let us first read the graph
setwd("C:/Users/anupams/OneDrive - Microsoft/Study/Summer 2018/Project 5")
graph_q4 = read.graph("Processed/weighted_edges.txt", format = "ncol", directed=TRUE )

## Let us find the top 10 actors in the graph using Page Rank Algorithm

rank <- page_rank(graph_q4, damping=0.85,directed= TRUE)$vector
top10rank <-  head(sort(rank, decreasing=TRUE), 10) 

name_map <- list()

## Let us read all the mapping files
map_actorid_name = read.delim("Processed/actorid_to_actor_name.txt", header= FALSE , sep ="\t")
map_actorid_mid  = read.delim("Processed/actorid_to_movieid_mapping.txt", header= FALSE , sep ="\t")
mapping_file = file("Processed/actorid_to_movieid_mapping.txt", "r")

## Let us find the name of the actors that are in top 10 per Page Rank

actor_name = map_actorid_name$V3[as.numeric(names(top10rank))+1]
actor_name = map_actorid_name$V3[as.numeric(names(top10rank))+1]
print(actor_name)

print(top10rank)

## Let us find thier degree and name of movies
## but before we find it we need to create the actor name map using our mapping file

var = 1

while(TRUE) {
  row = readLines(mapping_file, n=1)
  if(length(row) == 0 ) { break }
  string_vector = c()
  for(string in strsplit(row,"\t\t")) {
    string_vector = c(string_vector, as.numeric(string))
  }
  name_map[[var]] = string_vector
  var = var+1
}


in_degree = degree(graph_q4, mode="in")
for (id in as.numeric(names(top10rank))) {
  print(in_degree[toString(id)])
  print(length(name_map[[as.numeric(id) + 1]]) -1)
}


## This is for question 5, we need to get the number of degrees and number of movies for
## the name of actor that were listed in Question 3
## Page Rank for Question 5 and other data analysis is in python file

id_list = c(4503, 111298, 12812, 27258, 32389, 16878, 62774, 107832, 17285, 53248)
names(id_list) = c("Cruise, Tom", "Watson, Emma (II)", "Clooney, George", "Hanks, Tom", "Johnson, Dwayne (I)", "Depp, Johnny", "Smith, Will (I)", "Streep, Meryl", "DiCaprio, Leonardo", "Pitt, Brad")

for(id in as.numeric(id_list)) {
   print("00000000000")
   print(in_degree[toString(id)])
   print(length(name_map[[as.numeric(id) +1]]) -1 )
   print("&&&&&&&&&&&&&&&&&&&")
}


